/*
 * ZMap Copyright 2013 Regents of the University of Michigan
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <inttypes.h>

#include "../../lib/logger.h"
#include "../fieldset.h"

#include "output_modules.h"

// ---------- Modification ----------

#include <pcap.h>
#include <stdint.h>
#include <time.h>
#include <limits.h>
static pcap_t *pcap_handle = NULL;
static pcap_dumper_t *pcap_dumper = NULL;

// ---------- Modification ----------

static FILE *file = NULL;

int csv_init(struct state_conf *conf, const char **fields, int fieldlens)
{
	assert(conf);
	if (conf->output_filename) {
		if (!strcmp(conf->output_filename, "-")) {
			file = stdout;
		} else {
			if (!(file = fopen(conf->output_filename, "w"))) {
				log_fatal(
				    "csv",
				    "could not open CSV output file (%s): %s",
				    conf->output_filename, strerror(errno));
			}
		}
	} else {
		file = stdout;
		log_debug("csv", "no output file selected, will use stdout");
	}

	// ---------- Modification ----------

	/* Skipping the printing of header row without giving extra cmd args
	if (!conf->no_header_row) {
		log_debug("csv", "more than one field, will add headers");
		for (int i = 0; i < fieldlens; i++) {
			if (i) {
				fprintf(file, ",");
			}
			fprintf(file, "%s", fields[i]);
		}
		fprintf(file, "\n");
	}*/

	char output_dir[PATH_MAX];
	char final_path[PATH_MAX];

	strncpy(output_dir, conf->output_filename, PATH_MAX - 1);
	output_dir[PATH_MAX - 1] = '\0';

	char *last_slash = strrchr(output_dir, '/');
	if (last_slash) {
			*last_slash = '\0';  // Remove the filename part
	} else {
			strcpy(output_dir, "."); // Default to current directory
	}

	snprintf(final_path, sizeof(final_path), "%s/recv_pkts.pcap", output_dir);
	log_info("recv", "Output file: %s\n", final_path);

	// Open a dummy PCAP handle for writing packets
    pcap_handle = pcap_open_dead(DLT_EN10MB, 65535);
    if (!pcap_handle) {
        log_fatal("pcap", "failed to open pcap dead handle");
    }

    // Open the actual output file
    pcap_dumper = pcap_dump_open(pcap_handle, final_path);
    if (!pcap_dumper) {
        log_fatal("pcap", "could not open output file %s: %s",
                  conf->output_filename, pcap_geterr(pcap_handle));
    }

	// ---------- Modification ----------
	
	check_and_log_file_error(file, "csv");
	return EXIT_SUCCESS;
}

int csv_close(__attribute__((unused)) struct state_conf *c,
	      __attribute__((unused)) struct state_send *s,
	      __attribute__((unused)) struct state_recv *r)
{
	if (file) {
		fflush(file);
		fclose(file);
	}

	// ---------- Modification ----------

	// First close our current dumper but keep the handle
    if (pcap_dumper) {
        pcap_dump_close(pcap_dumper);
        pcap_dumper = NULL;
    }
    // Close our main pcap handle
    if (pcap_handle) {
        pcap_close(pcap_handle);
        pcap_handle = NULL;
    }

	// ---------- Modification ----------

	return EXIT_SUCCESS;
}

static void hex_encode(FILE *f, unsigned char *readbuf, size_t len)
{
	for (size_t i = 0; i < len; i++) {
		fprintf(f, "%02x", readbuf[i]);
	}
	check_and_log_file_error(f, "csv");
}

int csv_process(fieldset_t *fs)
{
	if (!file) {
		return EXIT_SUCCESS;
	}
	for (int i = 0; i < fs->len; i++) {
		field_t *f = &(fs->fields[i]);

		// ---------- Modification ----------

		if (strcmp(f->name, "recv") == 0) {
			struct pcap_pkthdr pcap_hdr;
			memset(&pcap_hdr, 0, sizeof(pcap_hdr));
			pcap_hdr.caplen = f->len;
			pcap_hdr.len = f->len;

			// Write the raw binary packet
			pcap_dump((u_char *)pcap_dumper, &pcap_hdr, (const u_char *)f->value.ptr);
			pcap_dump_flush(pcap_dumper);
			continue;
		}

		// ---------- Modification ----------

		if (i) {
			fprintf(file, ",");
		}
		if (f->type == FS_STRING) {
			if (strchr((char *)f->value.ptr, ',')) {
				fprintf(file, "\"%s\"", (char *)f->value.ptr);
			} else {
				fprintf(file, "%s", (char *)f->value.ptr);
			}
		} else if (f->type == FS_UINT64) {
			fprintf(file, "%" PRIu64, (uint64_t)f->value.num);
		} else if (f->type == FS_BOOL) {
			fprintf(file, "%" PRIi32, (int)f->value.num);
		} else if (f->type == FS_BINARY) {
			hex_encode(file, (unsigned char *)f->value.ptr, f->len);
		} else if (f->type == FS_NULL) {
			// do nothing
		} else {
			log_fatal("csv", "received unknown output type");
		}
	}
	fprintf(file, "\n");
	fflush(file);
	check_and_log_file_error(file, "csv");
	return EXIT_SUCCESS;
}

output_module_t module_csv_file = {
    .name = "csv",
    .init = &csv_init,
    .start = NULL,
    .update = NULL,
    .update_interval = 0,
    .close = &csv_close,
    .process_ip = &csv_process,
    .supports_dynamic_output = NO_DYNAMIC_SUPPORT,
    .helptext =
	"Outputs one or more output fields as a comma-delimited file. By default, the "
	"probe module does not filter out duplicates or limit to successful fields, "
	"but rather includes all received packets. Fields can be controlled by "
	"setting --output-fields. Filtering out failures and duplicate packets can "
	"be achieved by setting an --output-filter."};

